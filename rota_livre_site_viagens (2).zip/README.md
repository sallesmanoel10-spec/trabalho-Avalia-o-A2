# Rota Livre — site de viagens

Projeto acadêmico em HTML, CSS e JavaScript com 15 páginas responsivas.

## Páginas
1. Início (`index.html`)
2. Destinos (`destinos.html`)
3. Pacotes (`pacotes.html`)
4. Europa (`europa.html`)
5. Américas (`america.html`)
6. Ásia (`asia.html`)
7. Praias (`praias.html`)
8. Aventura (`aventura.html`)
9. Gastronomia (`gastronomia.html`)
10. Dicas (`dicas.html`)
11. Sobre (`sobre.html`)
12. Contato (`contato.html`)
13. Países — API REST Countries (`paises-api.html`)
14. Clima — API Open-Meteo (`clima-api.html`)
15. Cultura — API Wikipédia (`cultura-api.html`)

## Requisitos contemplados
- HTML semântico, CSS externo em `css/style.css` e JavaScript em `js/app.js`.
- CSS inline na página inicial e CSS interno na página de contato, além do CSS externo compartilhado.
- Seletores por tag, classe e ID.
- Interação JavaScript em todas as páginas (menu responsivo, salvar ideias, embaralhar cards ou consultas/formulário nas páginas específicas).
- Três integrações de API em páginas separadas:
  - REST Countries: consulta países.
  - Open-Meteo: geocodificação e clima atual.
  - Wikipédia REST API: resumo de destinos e lugares.
- Layout responsivo para celular e computador.

## Como abrir
Abra `index.html` no navegador. Para testar as APIs, é recomendado iniciar um servidor local (por exemplo, extensão Live Server do VS Code), pois algumas configurações do navegador restringem requisições locais.

## Publicar no GitHub
1. Crie um repositório público chamado `rota-livre`.
2. Extraia os arquivos deste ZIP.
3. Envie todos os arquivos e pastas para a raiz do repositório.
4. Acesse **Settings → Pages**.
5. Em **Build and deployment**, selecione **Deploy from a branch**.
6. Escolha a branch `main` e a pasta `/ (root)`, depois clique em **Save**.
7. Aguarde a publicação e acesse o endereço mostrado pelo GitHub Pages.

As consultas às APIs dependem de conexão com a internet. O formulário de contato é demonstrativo e não envia mensagens para um servidor.
